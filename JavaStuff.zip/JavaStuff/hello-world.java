//this is my first program! lets see if I can say "hello world"
public class HelloWorld { 
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
//wow! that was comlicated! in python its just "print("hello world")"
