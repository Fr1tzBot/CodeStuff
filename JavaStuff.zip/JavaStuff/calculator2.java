import java.lang.*;
import java.util.Scanner;

//Work in progress
//a remake of my python calculator
public class MyClass {
    public static void main(String args[])
        throws InterruptedException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("welcome to the java interactived calculator!");
        Thread.sleep(2000);
        System.out.println("This calulator will work as a calculator for dividing, multiplying, subtracting, adding, or exponents");
        System.out.println("with two numbers.");
        Thread.sleep(2000);
        System.out.println("first you will have to enter your first number, then your operator, and finally, your second number.");
        Thread.sleep(2000);
        Boolean rerun = true;
        int First_number = 0;
        String Second_number = "";
        String Operator = "";
        int First_numberint = 0;
        int Second_numberint = 0;
        while(rerun) {
            while(true){
                First_number =
            }
        }
        
    }
}
