import java.lang.math.*
public class creatingAFunction { 
    public static dist(l, n){
      int dif = (l-n)
      dif = java.lang.math.abs(dif)
      return dif
    }
}
