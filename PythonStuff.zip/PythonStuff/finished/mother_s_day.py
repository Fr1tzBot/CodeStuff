import time
print("Happy mother's day Mom!")
time.sleep(1)
print("Hope you have a great day!")
time.sleep(1)
print("Thanks for being an AMAZING Mom")
time.sleep(1)
print("love, Fritz")
print(":)")
