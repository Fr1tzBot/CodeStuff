playername = input("Please enter your name: ")
message = "Hello, " + playername
print(message)