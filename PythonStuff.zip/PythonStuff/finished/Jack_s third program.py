pevfe = input("how many people are in the world?")
print(pevfe)