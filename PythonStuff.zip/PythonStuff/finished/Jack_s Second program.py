pe = input("What is your name?")
message = ("hello " + pe)
print(message)