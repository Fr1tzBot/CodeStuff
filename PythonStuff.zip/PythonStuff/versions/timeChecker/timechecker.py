from time import ctime
print(ctime())

