# python_projects
this is a repository with all of the stuff I make using python

and whatever other languages I am using when I back up code
