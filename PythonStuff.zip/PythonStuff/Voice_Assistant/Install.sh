#!/bin/bash

sudo apt install git-all
sudo git clone https://github.com/thehacker55/Voice_Assistant_Python.git

#note:
#this script is only for if you don't have the neccesary packages installed
#it will not harm your computer, no matter if some are already installed
#just enter "y" ot all prompts
#(Linux ONLY)
