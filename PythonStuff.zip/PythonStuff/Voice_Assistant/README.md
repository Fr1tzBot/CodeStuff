# Voice_Assistant_Python

This repository is designed to hold scripts written in the proccess of making voice assistant from python scripts

It uses the google text to speech program and runs both online and offline

If you wish to contribute, just contact me or request to join via github

