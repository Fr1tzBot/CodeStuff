def distance(l, o):
  d = abs(l - o)
  return d