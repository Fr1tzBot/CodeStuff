def afternumber(i):
  st = (1,21,31,41,51,61,71,81,91,101,121)
  rd = (3,23,33,43,53,63,73,83,93,103,123)
  nd = (2,22,32,42,52,62,72,82,92,102,122)
  if i in st:
    return "st"
  elif i in rd:
    return "rd"
  elif i in nd:
    return "nd"
  else:
    return "th"